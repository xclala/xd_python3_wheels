def again(number):
	if number>0:
		int_number=number
		number=str(number)
		str_number=number*int_number
		number=int(str_number)
		del str_number,int_number
		return number
	else:
		raise ValueError("Enter numbers less than or equal to zero")
