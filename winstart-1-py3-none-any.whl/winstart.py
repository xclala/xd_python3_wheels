def start(program):
	from os import system
	system ("start "+program)
