def hypercube(length,dimensionality):
	return length**dimensionality