def slidetoshutdown(t):
	from os import system
	from time import sleep
	sleep(t)
	system("slidetoshutdown")