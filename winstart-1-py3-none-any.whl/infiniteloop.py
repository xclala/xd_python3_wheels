def loop(m):
	for i in iter(int,1):
		return m