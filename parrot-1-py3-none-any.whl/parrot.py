def parrot(text):
	return text
