def input_name(name):
	return "Hello,"+name+"!"