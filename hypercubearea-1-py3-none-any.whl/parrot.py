def parrot(m):
	return m